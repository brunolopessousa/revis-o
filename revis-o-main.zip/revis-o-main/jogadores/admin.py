from django.contrib import admin
from .models import Jogadores
# Register your models here.

admin.site.register(Jogadores)